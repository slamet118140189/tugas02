package com.example.tugas02.ui.skill

import android.media.Image
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugas02.R
import com.example.tugas02.databinding.FragmentSkillBinding
import com.example.tugas02.ui.SkillAdapter
import androidx.navigation.fragment.findNavController


class SkillFragment : Fragment() {

    private var _binding: FragmentSkillBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSkillBinding.inflate(inflater, container, false)
        val rootView = binding.root

       binding.button.setOnClickListener {
            // Tindakan yang akan diambil ketika tombol diklik
            // Misalnya, tampilkan pesan toast
           findNavController().navigate(R.id.action_nav_skill_to_nav_skilldetail2)
        }
        return rootView
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}