package com.example.tugas02.ui

class SkillAdapter {
}