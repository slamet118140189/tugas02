package com.example.tugas02.ui.skill

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.tugas02.R
import com.example.tugas02.databinding.FragmentSKillDetailBinding

class SKillDetailFragment : Fragment() {

    private var _binding: FragmentSKillDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSKillDetailBinding.inflate(inflater, container, false)
        val view = binding.root

        val skillDetailText = getString(R.string.textskilldetail) // Mengambil teks dari resources
        binding.skilldetaill.text = skillDetailText // Menampilkan teks ke TextView

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
